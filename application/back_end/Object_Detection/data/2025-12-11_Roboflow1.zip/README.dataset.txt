# Nutrition Identifier > 2025-12-11 9:31pm
https://universe.roboflow.com/nutrition-identifier/nutrition-identifier-x4sjn

Provided by a Roboflow user
License: CC BY 4.0

